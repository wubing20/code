from __future__ import annotations
import argparse
import csv
import json
from collections import Counter, defaultdict
from pathlib import Path
import sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import LogLocator, NullLocator
import networkx as nx
import numpy as np
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
COLORS = ('#8e44ad', '#2f6690', '#2ca25f', '#f4b400')

def read_rows(path):
    if path.parent == ROOT / 'data/network':
        from common.network_data import read_table
        return read_table(path.name)
    with path.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))

def write_rows(path: Path, fields: list[str], rows: list[dict]) -> None:
    with path.open('w', encoding='utf-8', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

def load_relations(data_dir: Path) -> tuple[nx.Graph, dict[int, set[int]]]:
    mapping = read_rows(data_dir / 'node_mapping.csv')
    nodes = [int(row['node_index']) for row in mapping]
    if not nodes or len(nodes) != len(set(nodes)):
        raise ValueError('node_mapping.csv must contain unique, nonempty node indices')
    graph = nx.Graph()
    graph.add_nodes_from(nodes)
    node_set = set(nodes)
    for row in read_rows(data_dir / 'pairwise_edges.csv'):
        u, v = (int(row['source_index']), int(row['target_index']))
        if u not in node_set or v not in node_set:
            raise ValueError('Pairwise edge references an undeclared node')
        if u == v or graph.has_edge(u, v):
            raise ValueError('Cleaned pairwise input contains a self-loop or duplicate edge')
        graph.add_edge(u, v)
    groups: dict[int, set[int]] = defaultdict(set)
    for row in read_rows(data_dir / 'hyperedge_incidence.csv'):
        edge_id, node = (int(row['hyperedge_id']), int(row['node_index']))
        if node not in node_set or node in groups[edge_id]:
            raise ValueError('Incidence input contains an unknown node or repeated membership')
        groups[edge_id].add(node)
    if not groups or any((len(members) < 2 for members in groups.values())):
        raise ValueError('Cleaned hyperedges must contain at least two distinct nodes')
    frozen = [frozenset(members) for members in groups.values()]
    if len(frozen) != len(set(frozen)):
        raise ValueError('Cleaned input contains duplicate hyperedges')
    compact = {}
    for row in read_rows(data_dir / 'hyperedges.csv'):
        edge_id = int(row['hyperedge_id'])
        raw_members = [int(value) for value in row['member_indices'].split()]
        members = set(raw_members)
        if edge_id in compact or len(raw_members) != len(members):
            raise ValueError('Compact hyperedge input contains duplicate IDs or members')
        if len(members) != int(row['size']):
            raise ValueError('Recorded hyperedge size differs from its actual membership')
        compact[edge_id] = members
    if compact != dict(groups):
        raise ValueError('hyperedges.csv and hyperedge_incidence.csv disagree')
    return (graph, dict(groups))

def distribution(values: np.ndarray) -> list[dict]:
    counts = Counter((int(value) for value in values))
    return [{'value': value, 'count': count, 'probability': count / len(values)} for value, count in sorted(counts.items())]

def calculate(graph: nx.Graph, groups: dict[int, set[int]]) -> tuple[dict, dict, list, list]:
    nodes = sorted(graph.nodes)
    degree = np.array([graph.degree(node) for node in nodes], dtype=np.int64)
    membership_counts = Counter((node for members in groups.values() for node in members))
    hyperdegree = np.array([membership_counts[node] for node in nodes], dtype=np.int64)
    sizes = np.array([len(members) for members in groups.values()], dtype=np.int64)
    components = sorted((len(component) for component in nx.connected_components(graph)), reverse=True)
    mean_degree = float(degree.mean())
    summary = {'nodes': len(nodes), 'pairwise_edges': graph.number_of_edges(), 'hyperedges': len(groups), 'incidences': int(sizes.sum()), 'mean_degree_k': mean_degree, 'max_degree_k': int(degree.max()), 'second_moment_over_mean_k': float(np.mean(degree.astype(float) ** 2) / mean_degree) if mean_degree else None, 'mean_hyperdegree_q': float(hyperdegree.mean()), 'max_hyperdegree_q': int(hyperdegree.max()), 'mean_hyperedge_size_s': float(sizes.mean()), 'max_hyperedge_size_s': int(sizes.max()), 'pairwise_components': len(components), 'pairwise_isolates': int(np.count_nonzero(degree == 0)), 'nodes_without_hyperedge': int(np.count_nonzero(hyperdegree == 0)), 'pairwise_largest_component_nodes': components[0], 'pairwise_largest_component_percent': components[0] / len(nodes) * 100}
    if int(degree.sum()) != 2 * graph.number_of_edges():
        raise AssertionError('Pairwise degree sum identity failed')
    if int(hyperdegree.sum()) != int(sizes.sum()):
        raise AssertionError('Hypergraph incidence sum identity failed')
    distributions = {'degree_k': distribution(degree), 'hyperdegree_q': distribution(hyperdegree), 'hyperedge_size_s': distribution(sizes)}
    per_node = [{'node_index': node, 'pairwise_degree_k': int(k), 'hyperdegree_q': int(q)} for node, k, q in zip(nodes, degree, hyperdegree)]
    ranked = [{'rank': rank, 'size': size, 'fraction_of_nodes': size / len(nodes)} for rank, size in enumerate(components, 1)]
    return (summary, distributions, per_node, ranked)

def draw_figure(summary: dict, distributions: dict, components: list, output_dir: Path) -> None:
    plt.rcParams.update({'font.family': 'serif', 'font.serif': ['Times New Roman', 'Times', 'DejaVu Serif'], 'font.size': 10, 'axes.titlesize': 13, 'axes.labelsize': 12, 'xtick.labelsize': 10, 'ytick.labelsize': 10, 'axes.edgecolor': '#1a1a1a', 'text.color': '#1a1a1a', 'svg.fonttype': 'none', 'pdf.fonttype': 42})
    fig = plt.figure(figsize=(10, 7.6), facecolor='white')
    positions = [(82, 84), (560, 84), (82, 450), (560, 450)]
    axes = [fig.add_axes([x / 1000, (760 - y - 245) / 760, 360 / 1000, 245 / 760]) for x, y in positions]
    titles = ['(a) Pairwise-degree distribution', '(b) Hyperdegree distribution', '(c) Hyperedge-size distribution', '(d) Pairwise-component rank-size profile']
    specs = [('degree_k', 'Pairwise degree, k', True), ('hyperdegree_q', 'Hyperdegree, q', False), ('hyperedge_size_s', 'Hyperedge size, s', True)]
    for ax, (key, label, logx), color, title in zip(axes, specs, COLORS, titles):
        entries = [entry for entry in distributions[key] if entry['value'] > 0 or not logx]
        x = [entry['value'] for entry in entries]
        y = [entry['probability'] for entry in entries]
        if not x:
            raise ValueError(f'No plottable values for {key}')
        if logx:
            ax.set_xscale('log')
        ax.set_yscale('log')
        ax.plot(x, y, color=color, marker='o', markersize=3.6 if logx else 4.2, linestyle='None' if logx else '-', linewidth=1.3, clip_on=False)
        low = min(x) if key == 'hyperedge_size_s' or min(x) == 0 else 1
        high = max(x)
        ax.set_xlim(low, high if high > low else low + 1)
        ax.set_ylim(min(y), 1)
        ax.set_xlabel(label, labelpad=12)
        ax.set_ylabel('Probability, ' + {'degree_k': 'P(k)', 'hyperdegree_q': 'P(q)', 'hyperedge_size_s': 'P(s)'}[key], labelpad=11)
        ax.set_title(title, pad=29)
        if not logx:
            step = max(1, int(np.ceil(high / 7)))
            ticks = list(range(int(low), int(high) + 1, step))
            ax.set_xticks(sorted(set(ticks + [high])))
    ax = axes[3]
    ranks = [entry['rank'] for entry in components]
    sizes = [entry['size'] for entry in components]
    ax.set_xscale('log')
    ax.set_yscale('log')
    ax.plot(ranks, sizes, linestyle='None', marker='o', color=COLORS[3], markersize=4.2, clip_on=False)
    ax.plot(ranks[0], sizes[0], marker='*', markersize=11, color=COLORS[3], markeredgecolor='#1a1a1a', markeredgewidth=0.7, clip_on=False)
    ax.set_xlim(1, max(2, len(components)))
    ax.set_ylim(1, max(2, sizes[0]))
    ax.set_xlabel('Component rank', labelpad=12)
    ax.set_ylabel('Component size', labelpad=11)
    ax.set_title(titles[3], pad=29)
    annotations = [f"N = {summary['nodes']:,}\nmean k = {summary['mean_degree_k']:.2f}", f"mean q = {summary['mean_hyperdegree_q']:.2f}\nmax q = {summary['max_hyperdegree_q']}", f"{summary['hyperedges']:,} hyperedges\nmean s = {summary['mean_hyperedge_size_s']:.2f}; max s = {summary['max_hyperedge_size_s']:,}", f"LCC = {summary['pairwise_largest_component_nodes']:,} nodes ({summary['pairwise_largest_component_percent']:.2f}%)"]
    for index, (ax, annotation) in enumerate(zip(axes, annotations)):
        text_x, alignment = (0.97, 'right') if index == 1 else (0.028, 'left')
        ax.text(text_x, 0.94, annotation, transform=ax.transAxes, ha=alignment, va='top', fontsize=10, bbox={'facecolor': 'white', 'alpha': 0.85, 'edgecolor': 'none', 'pad': 1.5})
        ax.grid(True, which='major', color='#d9d9d9', linewidth=0.7)
        ax.set_axisbelow(True)
        ax.tick_params(which='both', length=0, pad=6)
        ax.xaxis.set_minor_locator(NullLocator())
        ax.yaxis.set_minor_locator(NullLocator())
        if ax.get_xscale() == 'log':
            ax.xaxis.set_major_locator(LogLocator(base=10))
        if ax.get_yscale() == 'log':
            ax.yaxis.set_major_locator(LogLocator(base=10))
    for extension in ('svg', 'png', 'pdf'):
        fig.savefig(output_dir / f'figure_04_network_statistics.{extension}', dpi=180)
    plt.close(fig)

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-dir', type=Path, default=ROOT / 'data' / 'network')
    parser.add_argument('--output-dir', type=Path, default=ROOT / 'results' / 'experiment_01_network')
    args = parser.parse_args()
    graph, groups = load_relations(args.data_dir)
    summary, distributions, per_node, components = calculate(graph, groups)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    (args.output_dir / 'network_summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
    distribution_rows = [{'distribution': name, **entry} for name, entries in distributions.items() for entry in entries]
    write_rows(args.output_dir / 'network_distributions.csv', ['distribution', 'value', 'count', 'probability'], distribution_rows)
    write_rows(args.output_dir / 'node_statistics.csv', ['node_index', 'pairwise_degree_k', 'hyperdegree_q'], per_node)
    write_rows(args.output_dir / 'component_sizes.csv', ['rank', 'size', 'fraction_of_nodes'], components)
    draw_figure(summary, distributions, components, args.output_dir)
    print(json.dumps(summary, indent=2))
    print(f'Saved Figure 4 and calculated tables to {args.output_dir.resolve()}')
if __name__ == '__main__':
    main()
