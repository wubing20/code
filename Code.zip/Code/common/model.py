import csv
import json
import math
from dataclasses import dataclass, replace
from functools import lru_cache
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import brentq
from scipy.stats import binom
from common.network_data import NETWORK_SUMMARY, GROUPS

def load_network_summary():
    counts = {}
    for _, members in GROUPS:
        size = len(members)
        if size >= 3:
            counts[size] = counts.get(size, 0) + 1
    unique = np.array(sorted(counts), dtype=int)
    count = np.array([counts[s] for s in unique], dtype=float)
    incidence_weight = unique * count
    incidence_weight /= incidence_weight.sum()
    return (dict(NETWORK_SUMMARY), unique, incidence_weight)
NETWORK, GROUP_SIZES, GROUP_WEIGHTS = load_network_summary()
K_MEAN = float(NETWORK['mean_degree_k'])
Q_MEAN = float(NETWORK['mean_hyperdegree_q'])
GH_X, GH_W = np.polynomial.hermite.hermgauss(11)
GH_W = GH_W / math.sqrt(math.pi)

@dataclass(frozen=True)
class Parameters:
    beta_A_L: float = 0.0037
    beta_B_L: float = 0.00425
    beta_A_H: float = 0.038
    beta_B_H: float = 0.031
    alpha_A: float = 0.25
    alpha_B: float = 0.25
    mu_A: float = 0.1
    mu_B: float = 0.1
    mu_AB: float = 0.12
    omega: float = 0.018
    theta_A0: float = 0.3
    theta_B0: float = 0.28
    eta_B_to_A: float = 0.0
    eta_A_to_B: float = 0.0
    omega_aw: float = 0.0
    delta_aw: float = 0.1
    theta_aw: float = 0.2
    sigma_A: float = 0.2
    sigma_B: float = 0.2

def logistic(x):
    if x >= 0:
        z = math.exp(-x)
        return 1.0 / (1.0 + z)
    z = math.exp(x)
    return z / (1.0 + z)

def logit(p):
    return math.log(p / (1.0 - p))

def activation_probability(prevalence, threshold, sizes=GROUP_SIZES, weights=GROUP_WEIGHTS):
    p = float(np.clip(prevalence, 0.0, 1.0))
    theta = float(np.clip(threshold, 1e-08, 1 - 1e-08))
    n = sizes - 1
    required = np.ceil(theta * n).astype(int)
    tails = binom.sf(required - 1, n, p)
    return float(np.dot(weights, tails))

def _joint_activation_direct(prevalence, rival_prevalence, base, coupling, sizes, weights):
    p_i = float(np.clip(prevalence, 0.0, 1.0))
    p_j = float(np.clip(rival_prevalence, 0.0, 1.0))
    if abs(coupling) < 1e-14:
        return activation_probability(p_i, base, sizes, weights)
    total = 0.0
    for size, weight in zip(sizes, weights):
        n = int(size - 1)
        if n <= 25 or p_j <= 1e-10 or p_j >= 1 - 1e-10:
            rival_count = np.arange(n + 1)
            rival_prob = binom.pmf(rival_count, n, p_j)
            rival_fraction = rival_count / n
            theta = np.array([threshold(base, coupling, x) for x in rival_fraction])
            required = np.ceil(theta * n).astype(int)
            focal_tail = binom.sf(required - 1, n, p_i)
            group_probability = float(np.dot(rival_prob, focal_tail))
        else:
            std = math.sqrt(p_j * (1.0 - p_j) / n)
            rival_fraction = np.clip(p_j + math.sqrt(2.0) * std * GH_X, 0.0, 1.0)
            theta = np.array([threshold(base, coupling, x) for x in rival_fraction])
            required = np.ceil(theta * n).astype(int)
            focal_tail = binom.sf(required - 1, n, p_i)
            group_probability = float(np.dot(GH_W, focal_tail))
        total += float(weight) * group_probability
    return total
SURFACE_GRID = np.linspace(0.0, 0.65, 27)

@lru_cache(maxsize=96)
def _default_joint_surface(base, coupling):
    from common.surface_cache import cache_path, save
    path = cache_path(base, coupling, GROUP_SIZES, GROUP_WEIGHTS, SURFACE_GRID)
    if path.is_file():
        return np.load(path, allow_pickle=False)
    values = np.empty((len(SURFACE_GRID), len(SURFACE_GRID)), dtype=float)
    for i, p_i in enumerate(SURFACE_GRID):
        for j, p_j in enumerate(SURFACE_GRID):
            values[i, j] = _joint_activation_direct(p_i, p_j, base, coupling, GROUP_SIZES, GROUP_WEIGHTS)
    save(path, values)
    return values

def _bilinear_surface(values, p_i, p_j):
    x = float(np.clip(p_i, SURFACE_GRID[0], SURFACE_GRID[-1]))
    y = float(np.clip(p_j, SURFACE_GRID[0], SURFACE_GRID[-1]))
    ix = min(np.searchsorted(SURFACE_GRID, x, side='right') - 1, len(SURFACE_GRID) - 2)
    iy = min(np.searchsorted(SURFACE_GRID, y, side='right') - 1, len(SURFACE_GRID) - 2)
    ix, iy = (max(ix, 0), max(iy, 0))
    x0, x1 = (SURFACE_GRID[ix], SURFACE_GRID[ix + 1])
    y0, y1 = (SURFACE_GRID[iy], SURFACE_GRID[iy + 1])
    tx = (x - x0) / (x1 - x0)
    ty = (y - y0) / (y1 - y0)
    return float((1 - tx) * (1 - ty) * values[ix, iy] + tx * (1 - ty) * values[ix + 1, iy] + (1 - tx) * ty * values[ix, iy + 1] + tx * ty * values[ix + 1, iy + 1])

def joint_activation_probability(prevalence, rival_prevalence, base, coupling, sizes=GROUP_SIZES, weights=GROUP_WEIGHTS):
    if sizes is GROUP_SIZES and weights is GROUP_WEIGHTS and (abs(coupling) >= 1e-14):
        surface = _default_joint_surface(round(float(base), 8), round(float(coupling), 8))
        return _bilinear_surface(surface, prevalence, rival_prevalence)
    return _joint_activation_direct(prevalence, rival_prevalence, base, coupling, sizes, weights)

def threshold(base, coupling, rival_prevalence):
    return logistic(logit(base) - coupling * rival_prevalence)

def infection_force(pathogen, prevalence, rival_prevalence, p: Parameters, sizes=GROUP_SIZES, weights=GROUP_WEIGHTS):
    if pathogen == 'A':
        activation = joint_activation_probability(prevalence, rival_prevalence, p.theta_A0, p.eta_B_to_A, sizes, weights)
        return p.beta_A_L * K_MEAN * prevalence + p.beta_A_H * Q_MEAN * activation
    activation = joint_activation_probability(prevalence, rival_prevalence, p.theta_B0, p.eta_A_to_B, sizes, weights)
    return p.beta_B_L * K_MEAN * prevalence + p.beta_B_H * Q_MEAN * activation

def awareness_trigger(aware_fraction, p: Parameters, sizes=GROUP_SIZES, weights=GROUP_WEIGHTS):
    if p.omega_aw <= 0:
        return 0.0
    one_group = activation_probability(aware_fraction, p.theta_aw, sizes, weights)
    any_group = 1.0 - (1.0 - one_group) ** Q_MEAN
    return p.omega_aw * any_group

def rhs(_t, y, p: Parameters, sizes=GROUP_SIZES, weights=GROUP_WEIGHTS):
    SU, SA, EA, IA, EB, IB, IAB, R = np.maximum(y, 0.0)
    rho_A = IA + IAB
    rho_B = IB + IAB
    force_A = infection_force('A', rho_A, rho_B, p, sizes, weights)
    force_B = infection_force('B', rho_B, rho_A, p, sizes, weights)
    aware_rate = awareness_trigger(SA, p, sizes, weights)
    inf_A_U = force_A * SU
    inf_B_U = force_B * SU
    inf_A_A = (1.0 - p.sigma_A) * force_A * SA
    inf_B_A = (1.0 - p.sigma_B) * force_B * SA
    secondary_B = force_B * IA
    secondary_A = force_A * IB
    return np.array([p.omega * R + p.delta_aw * SA - aware_rate * SU - inf_A_U - inf_B_U, aware_rate * SU - p.delta_aw * SA - inf_A_A - inf_B_A, inf_A_U + inf_A_A - p.alpha_A * EA, p.alpha_A * EA - p.mu_A * IA - secondary_B, inf_B_U + inf_B_A - p.alpha_B * EB, p.alpha_B * EB - p.mu_B * IB - secondary_A, secondary_A + secondary_B - p.mu_AB * IAB, p.mu_A * IA + p.mu_B * IB + p.mu_AB * IAB - p.omega * R])

def integrate(y0, p, t_end=6000.0, dense=False, sizes=GROUP_SIZES, weights=GROUP_WEIGHTS):
    sol = solve_ivp(lambda t, y: rhs(t, y, p, sizes, weights), (0.0, t_end), np.asarray(y0, dtype=float), method='LSODA', rtol=2e-09, atol=1e-11, dense_output=dense, max_step=50.0)
    if not sol.success:
        raise RuntimeError(sol.message)
    y = np.maximum(sol.y[:, -1], 0.0)
    y /= y.sum()
    return (y, sol) if dense else y

def initial_state(rho_A=0.01, rho_B=0.01, aware=0.0):
    if rho_A + rho_B + aware >= 1:
        raise ValueError('Initial fractions must sum to less than one')
    return np.array([1 - rho_A - rho_B - aware, aware, 0, rho_A, 0, rho_B, 0, 0], dtype=float)

def resident_equilibrium(pathogen, p, aware_seed=0.0, sizes=GROUP_SIZES, weights=GROUP_WEIGHTS):
    if pathogen == 'A':
        y0 = initial_state(0.02, 0.0, aware_seed)
    else:
        y0 = initial_state(0.0, 0.02, aware_seed)
    return integrate(y0, p, sizes=sizes, weights=weights)

def force_slope_at_zero(pathogen, rival_prevalence, p, sizes=GROUP_SIZES, weights=GROUP_WEIGHTS):
    if pathogen == 'A':
        beta_l, beta_h = (p.beta_A_L, p.beta_A_H)
        base, coupling = (p.theta_A0, p.eta_B_to_A)
    else:
        beta_l, beta_h = (p.beta_B_L, p.beta_B_H)
        base, coupling = (p.theta_B0, p.eta_A_to_B)
    rival_p = float(np.clip(rival_prevalence, 0.0, 1.0))
    n = np.asarray(sizes, dtype=int) - 1
    target_logit = np.log(1.0 / n / (1.0 - 1.0 / n))
    gap = logit(base) - target_logit
    if abs(coupling) < 1e-14:
        probability = (gap <= 0).astype(float)
    elif coupling > 0:
        cutoff = gap / coupling
        required = np.ceil(n * cutoff).astype(int)
        probability = np.where(cutoff <= 0, 1.0, np.where(cutoff > 1, 0.0, binom.sf(required - 1, n, rival_p)))
    else:
        cutoff = gap / coupling
        maximum = np.floor(n * cutoff).astype(int)
        probability = np.where(cutoff < 0, 0.0, np.where(cutoff >= 1, 1.0, binom.cdf(maximum, n, rival_p)))
    higher_slope = float(np.dot(weights, n * probability))
    return beta_l * K_MEAN + beta_h * Q_MEAN * higher_slope

def invasion_growth(invader, resident_eq, p, sizes=GROUP_SIZES, weights=GROUP_WEIGHTS):
    SU, SA, EA, IA, EB, IB, IAB, R = resident_eq
    if invader == 'A':
        resident_prev = IB
        slope = force_slope_at_zero('A', resident_prev, p, sizes, weights)
        susceptible_weight = SU + (1 - p.sigma_A) * SA
        M = np.array([[-p.alpha_A, susceptible_weight * slope, susceptible_weight * slope], [p.alpha_A, -(p.mu_A + infection_force('B', resident_prev, 0.0, p, sizes, weights)), 0.0], [0.0, infection_force('B', resident_prev, 0.0, p, sizes, weights) + IB * slope, IB * slope - p.mu_AB]])
    else:
        resident_prev = IA
        slope = force_slope_at_zero('B', resident_prev, p, sizes, weights)
        susceptible_weight = SU + (1 - p.sigma_B) * SA
        M = np.array([[-p.alpha_B, susceptible_weight * slope, susceptible_weight * slope], [p.alpha_B, -(p.mu_B + infection_force('A', resident_prev, 0.0, p, sizes, weights)), 0.0], [0.0, infection_force('A', resident_prev, 0.0, p, sizes, weights) + IA * slope, IA * slope - p.mu_AB]])
    return float(np.max(np.linalg.eigvals(M).real))
