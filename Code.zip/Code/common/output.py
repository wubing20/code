from pathlib import Path
import argparse, csv, hashlib, json, platform, time
import numpy as np
import scipy
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT = Path(__file__).resolve().parents[1]
plt.rcParams.update({'font.family': 'Times New Roman', 'font.size': 10})

def output_dir(name):
    parser = argparse.ArgumentParser(description=name)
    parser.add_argument('--output-dir', type=Path)
    args = parser.parse_args()
    folder = args.output_dir or ROOT / 'results' / name
    folder.mkdir(parents=True, exist_ok=True)
    return folder

def write_csv(path, header, rows):
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)

def write_json(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')

def save_figure(fig, folder, name):
    fig.tight_layout()
    fig.savefig(folder / (name + '.svg'), facecolor='white')
    fig.savefig(folder / (name + '.png'), dpi=180, facecolor='white')
    plt.close(fig)

def finish(folder, start, details):
    write_json(folder / 'summary.json', details)
    print(folder.name, flush=True)
