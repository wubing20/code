from pathlib import Path
import sys, time
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from dataclasses import replace
import numpy as np
from common.config import BASE, INITIALS, COLORS
from common.model import initial_state, integrate, rhs
from common.numerics import reduced_stability
from common.output import output_dir, write_csv, save_figure, finish, plt

def run(folder):
    start = time.perf_counter()
    rows = []
    grid = np.array([0, 0.25, 0.5, 0.68, 0.739, 0.9, 1.1, 1.3, 1.5, 1.75, 2, 2.5, 3])
    fig, ax = plt.subplots(figsize=(6.5, 4.5))
    for name, (a0, b0) in INITIALS.items():
        aa = []
        bb = []
        for eta in grid:
            p = replace(BASE, eta_B_to_A=float(eta))
            y = integrate(initial_state(a0, b0), p, t_end=12000)
            a = float(y[3] + y[6])
            b = float(y[5] + y[6])
            e, _ = reduced_stability(y, p)
            rows.append((eta, name, a, b, e, float(abs(rhs(0, y, p)).max())))
            aa.append(a)
            bb.append(b)
        ax.plot(grid, aa, '-o', ms=3, label=name + ' A', color=COLORS[name])
        ax.plot(grid, bb, '--', label=name + ' B', color=COLORS[name])
    ax.set(xlabel='$\\eta_{B\\to A}$', ylabel='Endpoint infected fraction')
    ax.grid(alpha=0.25)
    ax.legend(fontsize=7, ncol=2)
    write_csv(folder / 'branches.csv', ['eta_B_to_A', 'initial_condition', 'rho_A', 'rho_B', 'central_eigenvalue', 'residual_inf'], rows)
    save_figure(fig, folder, 'competition_branches')
    finish(folder, start, {'parameter_points': len(grid), 'integrations': len(rows), 't_end': 12000})
if __name__ == '__main__':
    run(output_dir('experiment_03_competition_branches'))
