from __future__ import annotations
import copy
import re
from pathlib import Path
import xml.etree.ElementTree as ET
try:
    from .plot_layouts import PLOT_LAYOUTS
except ImportError:
    from plot_layouts import PLOT_LAYOUTS
SVG = 'http://www.w3.org/2000/svg'
ET.register_namespace('', SVG)
VISIBLE = {'rect', 'line', 'text', 'circle', 'polyline', 'polygon'}
NUMBER = re.compile('(?<![\\w])[-+]?\\d+(?:\\.\\d+)?(?:[eE][-+]?\\d+)?')

def _name(element):
    return element.tag.rsplit('}', 1)[-1]

def _plain_schema(value):
    return ' '.join(NUMBER.sub('{number}', value.replace('&gt;', '>')).split())

def _make_text(spec, computed_element):
    computed_text = ''.join(computed_element.itertext())
    expected = spec['computed_text_schema']
    if _plain_schema(expected) != _plain_schema(computed_text):
        raise ValueError('Label structure does not match layout.')

    def numeric_tokens(element):
        tokens = NUMBER.findall(element.text or '')
        for child in element:
            tokens.extend(numeric_tokens(child))
            tokens.extend(NUMBER.findall(child.tail or ''))
        return tokens
    numbers = numeric_tokens(computed_element)
    current_numbers = iter(numbers)
    count = 0

    def replace_number(match):
        nonlocal count
        count += 1
        try:
            return next(current_numbers)
        except StopIteration:
            raise ValueError('Numeric label structure differs from the static text layout') from None

    def make(tree):
        element = ET.Element(f'{{{SVG}}}' + tree['tag'], tree['attrs'])
        element.text = NUMBER.sub(replace_number, tree['text']) if tree['text'] else tree['text']
        for child in tree['children']:
            element.append(make(child))
        element.tail = NUMBER.sub(replace_number, tree['tail']) if tree['tail'] else tree['tail']
        return element
    result = make(spec['tree'])
    if count != len(numbers):
        raise ValueError('Numeric token count changed in the calculated text')
    return result

def apply_layout(figure: int, computed_svg: str | Path, output_svg: str | Path, layout_dir=None) -> Path:
    config = PLOT_LAYOUTS[figure]
    root = ET.parse(computed_svg).getroot()
    if root.get('data-generatedplot'):
        raise ValueError('Plot layout has already been applied.')
    fresh = [element for element in root if _name(element) in VISIBLE and element.get('width') != '100%']
    if [_name(element) for element in fresh] != [operation['tag'] for operation in config['operations']]:
        raise ValueError('Plot structure does not match layout.')
    result = ET.Element(f'{{{SVG}}}svg', {**config['root_attrs'], 'data-generatedplot': str(config['version'])})
    for element, operation in zip(fresh, config['operations']):
        kind = operation['kind']
        if kind == 'text':
            rendered = _make_text(operation, element)
        elif kind == 'static_layout':
            rendered = ET.Element(element.tag, operation['attrs'])
        elif kind == 'computed_geometry':
            rendered = copy.deepcopy(element)
            rendered.attrib.update(operation['style'])
            dx, dy = operation['translate']
            if dx or dy:
                if rendered.get('transform'):
                    raise ValueError('Unexpected transform on plot geometry.')
                rendered.set('transform', f'translate({dx:.12g},{dy:.12g})')
        else:
            raise ValueError(f'Unknown layout operation: {kind}')
        result.append(rendered)
    output_svg = Path(output_svg)
    output_svg.parent.mkdir(parents=True, exist_ok=True)
    ET.ElementTree(result).write(output_svg, encoding='utf-8', xml_declaration=True)
    return output_svg
