from pathlib import Path
import hashlib, os, uuid
import numpy as np
import scipy
ROOT = Path(__file__).resolve().parents[1]

def cache_path(base, coupling, sizes, weights, grid):
    h = hashlib.sha256()
    for f in ['model.py', 'surface_cache.py']:
        h.update((ROOT / 'common' / f).read_bytes())
    h.update(repr((base, coupling, np.__version__, scipy.__version__)).encode())
    for a in [sizes, weights, grid]:
        h.update(np.asarray(a).tobytes())
    folder = ROOT / 'results' / '_computed_surface_cache'
    folder.mkdir(parents=True, exist_ok=True)
    return folder / (h.hexdigest() + '.npy')

def save(path, array):
    temp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    with temp.open('wb') as f:
        np.save(f, array, allow_pickle=False)
    os.replace(temp, path)
