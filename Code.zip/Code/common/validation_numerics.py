from dataclasses import replace
import numpy as np
from common import model as m
from common.config import BASE
B_GRID = np.linspace(0, 0.65, 2001)
B_VALUES = np.array([m.activation_probability(x, BASE.theta_B0) for x in B_GRID])

def interp2(values, x, y):
    grid = m.SURFACE_GRID
    x = np.clip(x, grid[0], grid[-1])
    y = np.clip(y, grid[0], grid[-1])
    ix = np.clip(np.searchsorted(grid, x, side='right') - 1, 0, len(grid) - 2)
    iy = np.clip(np.searchsorted(grid, y, side='right') - 1, 0, len(grid) - 2)
    x0, x1 = (grid[ix], grid[ix + 1])
    y0, y1 = (grid[iy], grid[iy + 1])
    tx = (x - x0) / (x1 - x0)
    ty = (y - y0) / (y1 - y0)
    return (1 - tx) * (1 - ty) * values[ix, iy] + tx * (1 - ty) * values[ix + 1, iy] + (1 - tx) * ty * values[ix, iy + 1] + tx * ty * values[ix + 1, iy + 1]

def vector_rhs(y, p, surface_a, b_grid, b_values):
    y = np.maximum(y, 0.0)
    SU, SA, EA, IA, EB, IB, IAB, R = y.T
    rho_a = IA + IAB
    rho_b = IB + IAB
    act_a = interp2(surface_a, rho_a, rho_b)
    act_b = np.interp(np.clip(rho_b, 0, 0.65), b_grid, b_values)
    force_a = p.beta_A_L * m.K_MEAN * rho_a + p.beta_A_H * m.Q_MEAN * act_a
    force_b = p.beta_B_L * m.K_MEAN * rho_b + p.beta_B_H * m.Q_MEAN * act_b
    inf_au = force_a * SU
    inf_bu = force_b * SU
    inf_aa = (1 - p.sigma_A) * force_a * SA
    inf_ba = (1 - p.sigma_B) * force_b * SA
    secondary_b = force_b * IA
    secondary_a = force_a * IB
    return np.column_stack((p.omega * R + p.delta_aw * SA - inf_au - inf_bu, -p.delta_aw * SA - inf_aa - inf_ba, inf_au + inf_aa - p.alpha_A * EA, p.alpha_A * EA - p.mu_A * IA - secondary_b, inf_bu + inf_ba - p.alpha_B * EB, p.alpha_B * EB - p.mu_B * IB - secondary_a, secondary_a + secondary_b - p.mu_AB * IAB, p.mu_A * IA + p.mu_B * IB + p.mu_AB * IAB - p.omega * R))

def integrate_batch(y, alpha, t_end=6000.0, dt=1.0, probe=1e-06):
    p = replace(BASE, eta_B_to_A=float(alpha))
    surface_a = m._default_joint_surface(round(p.theta_A0, 8), round(p.eta_B_to_A, 8))
    y = np.asarray(y, float).copy()
    steps = int(round(t_end / dt))
    for _ in range(steps):
        k1 = vector_rhs(y, p, surface_a, B_GRID, B_VALUES)
        k2 = vector_rhs(y + dt * k1, p, surface_a, B_GRID, B_VALUES)
        y += 0.5 * dt * (k1 + k2)
        y = np.maximum(y, 0.0)
        total = y.sum(axis=1)
        y /= total[:, None]
        rho_a = y[:, 3] + y[:, 6]
        rho_b = y[:, 5] + y[:, 6]
        need_a = rho_a < probe
        need_b = rho_b < probe
        add_a = np.where(need_a, probe - rho_a, 0.0)
        add_b = np.where(need_b, probe - rho_b, 0.0)
        take = np.minimum(y[:, 0], add_a + add_b)
        denom = add_a + add_b
        scale = np.divide(take, denom, out=np.zeros_like(take), where=denom > 0)
        y[:, 0] -= take
        y[:, 2] += 0.5 * add_a * scale
        y[:, 3] += 0.5 * add_a * scale
        y[:, 4] += 0.5 * add_b * scale
        y[:, 5] += 0.5 * add_b * scale
    return y

def reduced_jacobian(y, p, one_sided=False):
    z = np.asarray(y[:7], float)
    f0 = m.rhs(0, y, p)[:7]
    J = np.empty((7, 7))
    h = 1e-07
    for j in range(7):
        e = np.zeros(7)
        e[j] = h
        yp = np.r_[z + e, 1 - (z + e).sum()]
        if one_sided:
            J[:, j] = (m.rhs(0, yp, p)[:7] - f0) / h
        else:
            ym = np.r_[z - e, 1 - (z - e).sum()]
            J[:, j] = (m.rhs(0, yp, p)[:7] - m.rhs(0, ym, p)[:7]) / (2 * h)
    eig = np.linalg.eigvals(J)
    return (J, eig)
