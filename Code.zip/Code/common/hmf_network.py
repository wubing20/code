from __future__ import annotations
from collections import Counter, defaultdict
from pathlib import Path
import sys
import csv, hashlib, json
import numpy as np
from scipy.sparse import coo_matrix, save_npz
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

def rows(path):
    if path.parent == ROOT / 'data/network':
        from common.network_data import read_table
        return read_table(path.name)
    with path.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))

def build(data_dir=ROOT / 'data/network', minimum_group_size=2):
    if minimum_group_size not in (2, 3):
        raise ValueError('Choose an explicit retained group definition: 2 or 3.')
    mapping = rows(data_dir / 'node_mapping.csv')
    nodes = np.array(sorted((int(x['node_index']) for x in mapping)))
    if len(set(nodes)) != len(nodes):
        raise ValueError('Repeated node index')
    index = {int(node): i for i, node in enumerate(nodes)}
    edges = []
    seen_edges = set()
    k = np.zeros(len(nodes), int)
    for row in rows(data_dir / 'pairwise_edges.csv'):
        u, v = sorted((int(row['source_index']), int(row['target_index'])))
        if u not in index or v not in index or u == v or ((u, v) in seen_edges):
            raise ValueError('Invalid pairwise edge')
        seen_edges.add((u, v))
        edges.append((index[u], index[v]))
        k[index[u]] += 1
        k[index[v]] += 1
    groups = []
    group_ids = []
    q = np.zeros(len(nodes), int)
    all_ids = set()
    for row in rows(data_dir / 'hyperedges.csv'):
        edge_id = int(row['hyperedge_id'])
        members = [int(x) for x in row['member_indices'].split()]
        if edge_id in all_ids or len(members) != len(set(members)) or len(members) != int(row['size']):
            raise ValueError('Invalid hyperedge')
        if any((x not in index for x in members)):
            raise ValueError('Unknown hyperedge node')
        all_ids.add(edge_id)
        if len(members) >= minimum_group_size:
            members = np.array([index[x] for x in members], int)
            groups.append(members)
            group_ids.append(edge_id)
            q[members] += 1
    pairs = np.column_stack((k, q))
    classes, class_index, class_counts = np.unique(pairs, axis=0, return_inverse=True, return_counts=True)
    probability = class_counts / len(nodes)
    sizes, size_counts = np.unique([len(x) for x in groups], return_counts=True)
    size_index = {int(s): i for i, s in enumerate(sizes)}
    count = np.zeros((len(classes), len(sizes)), np.int64)
    for members in groups:
        count[:, size_index[len(members)]] += np.bincount(class_index[members], minlength=len(classes))
    class_incidence = count.sum(axis=1)
    conditional = np.divide(count, class_incidence[:, None], out=np.zeros(count.shape, float), where=class_incidence[:, None] > 0)
    class_given_size = count.T / (sizes * size_counts)[:, None]
    c1 = []
    c2 = []
    for u, v in edges:
        c1.extend((class_index[u], class_index[v]))
        c2.extend((class_index[v], class_index[u]))
    mixing = coo_matrix((np.ones(len(c1), dtype=np.int64), (c1, c2)), shape=(len(classes), len(classes))).tocsr()
    assert np.array_equal(class_incidence, class_counts * classes[:, 1])
    assert np.array_equal(count.sum(axis=0), sizes * size_counts)
    assert np.array_equal(np.asarray(mixing.sum(axis=1)).ravel(), class_counts * classes[:, 0])
    assert np.isclose(probability.sum(), 1)
    assert np.allclose(conditional[classes[:, 1] > 0].sum(axis=1), 1)
    assert np.allclose(class_given_size.sum(axis=1), 1)
    return dict(nodes=nodes, k=k, q=q, classes=classes, class_index=class_index, class_counts=class_counts, probability=probability, sizes=sizes, size_counts=size_counts, class_size_incidence_counts=count, conditional_size_given_class=conditional, conditional_class_given_size=class_given_size, pairwise_class_counts=mixing, minimum_group_size=minimum_group_size, group_count=len(groups), edge_count=len(edges))

def write(data, folder, data_dir=ROOT / 'data/network'):
    folder.mkdir(parents=True, exist_ok=True)
    keys = ['nodes', 'k', 'q', 'classes', 'class_index', 'class_counts', 'probability', 'sizes', 'size_counts', 'class_size_incidence_counts', 'conditional_size_given_class', 'conditional_class_given_size']
    target = folder / 'class_distributions.npz'
    same = False
    if target.exists():
        with np.load(target, allow_pickle=False) as existing:
            same = set(existing.files) == set(keys) and all((np.array_equal(existing[k], data[k]) for k in keys))
    if not same:
        np.savez_compressed(target, **{k: data[k] for k in keys})
    target = folder / 'pairwise_class_counts.npz'
    if target.exists():
        from scipy.sparse import load_npz
        same = (load_npz(target) != data['pairwise_class_counts']).nnz == 0
    else:
        same = False
    if not same:
        save_npz(target, data['pairwise_class_counts'])
    with (folder / 'classes.csv').open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.writer(f)
        w.writerow(['class_id', 'k', 'q', 'node_count', 'P_kq'])
        w.writerows(((i, int(k), int(q), int(data['class_counts'][i]), float(data['probability'][i])) for i, (k, q) in enumerate(data['classes'])))
    with (folder / 'conditional_group_sizes.csv').open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.writer(f)
        w.writerow(['class_id', 'k', 'q', 'size', 'incidence_count', 'P_size_given_class'])
        for i, (k, q) in enumerate(data['classes']):
            for j, s in enumerate(data['sizes']):
                n = int(data['class_size_incidence_counts'][i, j])
                if n:
                    w.writerow([i, int(k), int(q), int(s), n, float(data['conditional_size_given_class'][i, j])])
    files = ['node_mapping.csv', 'pairwise_edges.csv', 'hyperedges.csv']
    summary = {'minimum_group_size': data['minimum_group_size'], 'nodes': len(data['nodes']), 'pairwise_edges': data['edge_count'], 'hyperedges': data['group_count'], 'incidences': int(data['q'].sum()), 'occupied_classes': len(data['classes']), 'state_dimension': 8 * len(data['classes']), 'mean_degree': float(data['k'].mean()), 'mean_hyperdegree': float(data['q'].mean())}
    (folder / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
    return summary
if __name__ == '__main__':
    for minimum in (2, 3):
        print(json.dumps(write(build(minimum_group_size=minimum), ROOT / 'data/hmf' / f'groups_at_least_{minimum}'), ensure_ascii=False))
