from pathlib import Path
import sys, time
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
from common.output import ROOT, output_dir, write_csv, save_figure, finish, plt

def run(folder):
    start = time.perf_counter()
    source = ROOT / 'results/experiment_09_dense_basins/basin_grid.npz'
    if not source.exists():
        from experiments.experiment_09_dense_basins import run as run_basins
        source.parent.mkdir(parents=True, exist_ok=True)
        run_basins(source.parent)
    data = np.load(source)
    labels = data['labels']
    axis = data['x'][0]
    valid_labels = labels[np.isfinite(labels)]
    fractions = {name: float(np.mean(valid_labels == v)) for name, v in [('coexistence', 2), ('A_only', 1), ('B_only', 0)]}
    pixels = np.array([1, 2, 3, 4, 6, 8, 12])
    uncertain = []
    for k in pixels:
        changed = np.zeros(labels.shape, bool)
        comparable = np.zeros(labels.shape, bool)
        for di, dj in [(k, 0), (-k, 0), (0, k), (0, -k)]:
            shifted = np.roll(labels, (di, dj), (0, 1))
            valid = np.isfinite(labels) & np.isfinite(shifted)
            if di > 0:
                valid[:di, :] = False
            if di < 0:
                valid[di:, :] = False
            if dj > 0:
                valid[:, :dj] = False
            if dj < 0:
                valid[:, dj:] = False
            comparable |= valid
            changed |= valid & (labels != shifted)
        uncertain.append(float(changed.sum() / comparable.sum()))
    uncertain = np.array(uncertain)
    eps = pixels * (axis[1] - axis[0])
    positive = uncertain > 0
    gamma = float(np.polyfit(np.log(eps[positive]), np.log(uncertain[positive]), 1)[0])
    write_csv(folder / 'uncertainty.csv', ['epsilon_pixels', 'epsilon', 'uncertain_fraction'], zip(pixels, eps, uncertain))
    fig, axes = plt.subplots(1, 2, figsize=(10, 4))
    vals = [100 * fractions[n] for n in ['coexistence', 'A_only', 'B_only']]
    axes[0].bar(['Coexistence', 'A-only', 'B-only'], vals, color=['#2ca25f', '#cf3c2b', '#1f4e79'])
    axes[0].set(ylabel='Area fraction (%)', ylim=(0, 105))
    for i, v in enumerate(vals):
        axes[0].text(i, v + 2, f'{v:.1f}%', ha='center')
    axes[1].loglog(eps, uncertain, 'o-')
    axes[1].set(xlabel='$\\epsilon$', ylabel='$f(\\epsilon)$', title=f'gamma={gamma:.6f}, D={2 - gamma:.6f}')
    axes[1].grid(alpha=0.25)
    save_figure(fig, folder, 'area_and_boundary')
    import hashlib
    finish(folder, start, {'basin_area_fractions': fractions, 'uncertainty_exponent': gamma, 'basin_boundary_dimension': 2 - gamma, 'uncertainty_epsilon_pixels': pixels.tolist(), 'uncertain_fractions': uncertain.tolist(), 'source_basin_sha256': hashlib.sha256(source.read_bytes()).hexdigest()})
if __name__ == '__main__':
    run(output_dir('experiment_10_boundary_uncertainty'))
