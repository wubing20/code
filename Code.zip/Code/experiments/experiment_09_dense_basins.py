from pathlib import Path
import sys, time
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
from matplotlib.colors import ListedColormap
from common.validation_numerics import integrate_batch
from common.output import output_dir, write_csv, save_figure, finish, plt

def run(folder):
    start = time.perf_counter()
    axis = np.linspace(0.002, 0.798, 201)
    xx, yy = np.meshgrid(axis, axis)
    mask = xx + yy <= 0.8
    points = np.column_stack((xx[mask], yy[mask]))
    y = np.zeros((len(points), 8))
    y[:, 0] = 1 - points[:, 0] - points[:, 1]
    y[:, 3] = points[:, 0]
    y[:, 5] = points[:, 1]
    final = integrate_batch(y, 0.739, t_end=6000)
    a = final[:, 3] + final[:, 6]
    b = final[:, 5] + final[:, 6]
    co = (a > 1e-05) & (b > 1e-05)
    onlya = (a > 1e-05) & ~co
    onlyb = (b > 1e-05) & ~co
    labels = np.full(xx.shape, np.nan)
    labels[mask] = np.where(co, 2, np.where(onlya, 1, 0))
    np.savez_compressed(folder / 'basin_grid.npz', x=xx, y=yy, labels=labels)
    np.savez_compressed(folder / 'final_states.npz', initial_points=points, final_states=final)
    write_csv(folder / 'basin_points.csv', ['initial_rho_A', 'initial_rho_B', 'final_rho_A', 'final_rho_B', 'label'], zip(points[:, 0], points[:, 1], a, b, labels[mask]))
    fig, ax = plt.subplots(figsize=(6.5, 4.5))
    ax.pcolormesh(xx, yy, np.ma.masked_invalid(labels), shading='auto', cmap=ListedColormap(['#1f4e79', '#cf3c2b', '#2ca25f']), vmin=0, vmax=2)
    ax.set(xlabel='$\\rho_A(0)$', ylabel='$\\rho_B(0)$', title='201×201 slice at $\\eta_{B\\to A}=0.739$')
    save_figure(fig, folder, 'dense_basins')
    finish(folder, start, {'grid_resolution': [201, 201], 'admissible_grid_points': len(points), 'basin_area_fractions': {'coexistence': float(co.mean()), 'A_only': float(onlya.mean()), 'B_only': float(onlyb.mean())}, 'max_mass_error': float(abs(final.sum(axis=1) - 1).max()), 'minimum_final_state': float(final.min()), 't_end': 6000, 'dt': 1.0, 'probe': 1e-06, 'classification_threshold': 1e-05})
if __name__ == '__main__':
    run(output_dir('experiment_09_dense_basins'))
