from __future__ import annotations
import csv
import html
import json
import math
from collections import Counter
from pathlib import Path
W, H = (1000, 760)
PW, PH = (360, 245)
POSITIONS = [(82, 84), (560, 84), (82, 450), (560, 450)]
PURPLE = '#8e44ad'
BLUE = '#2f6690'
GREEN = '#2ca25f'
ORANGE = '#f4b400'
GRID = '#d9d9d9'
TEXT = '#1a1a1a'

def esc(value: object) -> str:
    return html.escape(str(value), quote=True)

def txt(x, y, value, size=12, anchor='middle', italic=False, weight='normal'):
    style = 'font-style:italic;' if italic else ''
    return f'<text x="{x:.2f}" y="{y:.2f}" text-anchor="{anchor}" font-family="Times New Roman,Times,serif" font-size="{size}" font-weight="{weight}" fill="{TEXT}" style="{style}">{esc(value)}</text>'

def log_ticks(vmin, vmax):
    lo = math.floor(math.log10(vmin))
    hi = math.ceil(math.log10(vmax))
    return [10.0 ** p for p in range(lo, hi + 1) if vmin <= 10.0 ** p <= vmax]

def fmt_tick(v, log=False):
    if log and v < 0.01:
        return f'10^{int(round(math.log10(v)))}'
    if log and v >= 1000:
        return f'10^{int(round(math.log10(v)))}'
    if abs(v - round(v)) < 1e-09:
        return str(int(round(v)))
    return f'{v:g}'

def axes(parts, x, y, w, h, xlim, ylim, xticks, yticks, xlabel, ylabel, logx=False, logy=False):

    def tx(v):
        a, b = xlim
        if logx:
            v, a, b = (math.log10(v), math.log10(a), math.log10(b))
        return x + (v - a) / (b - a) * w

    def ty(v):
        a, b = ylim
        if logy:
            v, a, b = (math.log10(v), math.log10(a), math.log10(b))
        return y + h - (v - a) / (b - a) * h
    parts.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="white" stroke="{TEXT}" stroke-width="1.2"/>')
    for v in xticks:
        px = tx(v)
        parts.append(f'<line x1="{px:.2f}" y1="{y}" x2="{px:.2f}" y2="{y + h}" stroke="{GRID}" stroke-width="0.8"/>')
        label = fmt_tick(v, logx)
        if label.startswith('10^'):
            power = label[3:]
            parts.append(f'<text x="{px:.2f}" y="{y + h + 18}" text-anchor="middle" font-family="Times New Roman,Times,serif" font-size="10" fill="{TEXT}">10<tspan baseline-shift="super" font-size="7">{power}</tspan></text>')
        else:
            parts.append(txt(px, y + h + 18, label, 10))
    for v in yticks:
        py = ty(v)
        parts.append(f'<line x1="{x}" y1="{py:.2f}" x2="{x + w}" y2="{py:.2f}" stroke="{GRID}" stroke-width="0.8"/>')
        label = fmt_tick(v, logy)
        if label.startswith('10^'):
            power = label[3:]
            parts.append(f'<text x="{x - 9}" y="{py + 3}" text-anchor="end" font-family="Times New Roman,Times,serif" font-size="10" fill="{TEXT}">10<tspan baseline-shift="super" font-size="7">{power}</tspan></text>')
        else:
            parts.append(txt(x - 9, py + 3, label, 10, 'end'))
    parts.append(txt(x + w / 2, y + h + 46, xlabel, 12))
    parts.append(f'<text transform="translate({x - 52},{y + h / 2}) rotate(-90)" text-anchor="middle" font-family="Times New Roman,Times,serif" font-size="12" fill="{TEXT}">{esc(ylabel)}</text>')
    return (tx, ty)

def _read_results(results_dir: Path):
    distributions = {}
    with (results_dir / 'network_distributions.csv').open(encoding='utf-8-sig', newline='') as handle:
        for row in csv.DictReader(handle):
            distributions.setdefault(row['distribution'], []).append((float(row['value']), float(row['probability'])))
    for values in distributions.values():
        values.sort(key=lambda item: item[0])
    with (results_dir / 'component_sizes.csv').open(encoding='utf-8-sig', newline='') as handle:
        component_rows = sorted(csv.DictReader(handle), key=lambda row: int(row['rank']))
    components = [int(row['size']) for row in component_rows]
    summary = json.loads((results_dir / 'network_summary.json').read_text(encoding='utf-8-sig'))
    return (distributions, components, summary)

def points(parts, data, tx, ty, color, radius=3.1, line=True):
    mapped = [(tx(a), ty(b)) for a, b in data if a > 0 and b > 0]
    if line and len(mapped) > 1:
        parts.append(f'''<polyline points="{' '.join((f'{x:.2f},{y:.2f}' for x, y in mapped))}" fill="none" stroke="{color}" stroke-width="1.6" opacity="0.9"/>''')
    for x, y in mapped:
        parts.append(f'<circle cx="{x:.2f}" cy="{y:.2f}" r="{radius}" fill="{color}"/>')

def render_network(results_dir: Path | str, output_svg: Path | str) -> Path:
    results_dir = Path(results_dir)
    output_svg = Path(output_svg)
    d, comps, summary = _read_results(results_dir)
    parts = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">', '<title>Structural diagnostics of the retained baseline network</title>', f"<desc>Degree, hyperdegree, hyperedge-size, and connected-component statistics for the cleaned {summary['nodes']}-node bilayer network.</desc>", '<rect width="100%" height="100%" fill="white"/>']
    x, y = POSITIONS[0]
    vals = d['degree_k']
    tx, ty = axes(parts, x, y, PW, PH, (1, max((a for a, _ in vals))), (min((b for _, b in vals)), 1), log_ticks(1, max((a for a, _ in vals))), log_ticks(min((b for _, b in vals)), 1), 'Pairwise degree, k', 'Probability, P(k)', True, True)
    parts.append(txt(x + PW / 2, 28, '(a) Pairwise-degree distribution', 13))
    points(parts, vals, tx, ty, PURPLE, 2.6, False)
    parts.append(txt(x + 10, y + 19, f"N = {summary['nodes']:,}", 10, 'start'))
    parts.append(txt(x + 10, y + 34, f"mean k = {summary['mean_degree_k']:.2f}", 10, 'start'))
    x, y = POSITIONS[1]
    vals = d['hyperdegree_q']
    tx, ty = axes(parts, x, y, PW, PH, (1, summary['max_hyperdegree_q']), (min((b for _, b in vals)), 1), list(range(1, summary['max_hyperdegree_q'] + 1, 2)), log_ticks(min((b for _, b in vals)), 1), 'Hyperdegree, q', 'Probability, P(q)', False, True)
    parts.append(txt(x + PW / 2, 28, '(b) Hyperdegree distribution', 13))
    points(parts, vals, tx, ty, BLUE, 3.0, True)
    parts.append(txt(x + 10, y + 19, f"mean q = {summary['mean_hyperdegree_q']:.2f}", 10, 'start'))
    parts.append(txt(x + 10, y + 34, f"max q = {summary['max_hyperdegree_q']}", 10, 'start'))
    x, y = POSITIONS[2]
    vals = d['hyperedge_size_s']
    tx, ty = axes(parts, x, y, PW, PH, (2, max((a for a, _ in vals))), (min((b for _, b in vals)), 1), log_ticks(2, max((a for a, _ in vals))), log_ticks(min((b for _, b in vals)), 1), 'Hyperedge size, s', 'Probability, P(s)', True, True)
    parts.append(txt(x + PW / 2, 396, '(c) Hyperedge-size distribution', 13))
    points(parts, vals, tx, ty, GREEN, 3.0, False)
    parts.append(txt(x + 10, y + 19, f"{summary['hyperedges']} hyperedges", 10, 'start'))
    parts.append(txt(x + 10, y + 34, f"mean s = {summary['mean_hyperedge_size_s']:.2f}; max s = {summary['max_hyperedge_size_s']:,}", 10, 'start'))
    x, y = POSITIONS[3]
    rank_data = [(i + 1, float(v)) for i, v in enumerate(comps)]
    tx, ty = axes(parts, x, y, PW, PH, (1, max(2, len(comps))), (1, max(comps)), log_ticks(1, max(2, len(comps))), log_ticks(1, max(comps)), 'Component rank', 'Component size', True, True)
    parts.append(txt(x + PW / 2, 396, '(d) Pairwise-component rank-size profile', 13))
    points(parts, rank_data, tx, ty, ORANGE, 3.0, False)
    lcc = comps[0]
    parts.append(txt(x + 10, y + 19, f"LCC = {lcc:,} nodes ({summary['pairwise_largest_component_percent']:.2f}%)", 10, 'start'))
    px, py = (tx(1), ty(lcc))
    parts.append(f'<polygon points="{px:.2f},{py - 7:.2f} {px - 2.2:.2f},{py - 2.2:.2f} {px - 7:.2f},{py - 2.2:.2f} {px - 3.2:.2f},{py + 1.3:.2f} {px - 4.5:.2f},{py + 6.5:.2f} {px:.2f},{py + 3.5:.2f} {px + 4.5:.2f},{py + 6.5:.2f} {px + 3.2:.2f},{py + 1.3:.2f} {px + 7:.2f},{py - 2.2:.2f} {px + 2.2:.2f},{py - 2.2:.2f}" fill="#f4b400" stroke="#1a1a1a" stroke-width="0.8"/>')
    parts.append('</svg>')
    output_svg.parent.mkdir(parents=True, exist_ok=True)
    output_svg.write_text('\n'.join(parts), encoding='utf-8')
    return output_svg
