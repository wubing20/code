from pathlib import Path
import sys, time
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
from common.validation_numerics import integrate_batch
from common.output import output_dir, write_csv, save_figure, finish, plt

def run(folder):
    start = time.perf_counter()
    grid = np.array([0, 0.2, 0.3, 0.34, 0.5, 0.739, 1, 1.5, 2, 2.01, 2.012, 2.5])
    scans = []
    full_states = []
    for direction, seq, state in [('forward', grid, [0.99999999, 0, 0, 1e-10, 0, 9.9e-09, 0, 0]), ('reverse', grid[::-1], [0.99999999, 0, 0, 9.9e-09, 0, 1e-10, 0, 0])]:
        y = np.array([state])
        vals = []
        for eta in seq:
            y = integrate_batch(y, float(eta), t_end=6000)
            full_states.append((direction, float(eta), *y[0]))
            vals.append((float(y[0, 3] + y[0, 6]), float(y[0, 5] + y[0, 6])))
            print(direction, float(eta), vals[-1], flush=True)
        scans.append(np.array(vals if direction == 'forward' else vals[::-1]))
    f, r = scans
    high = (f[:, 0] > 1e-05) & (f[:, 1] <= 1e-05)
    jumps = [(float(grid[i - 1]), float(grid[i])) for i in range(1, len(grid)) if not high[i - 1] and high[i]]
    reverse_switch = bool(np.any(~((r[:, 0] > 1e-05) & (r[:, 1] <= 1e-05))))
    lower = None if not jumps or reverse_switch else jumps[0][0] - float(grid[0])
    write_csv(folder / 'directional_scan.csv', ['eta_B_to_A', 'forward_A', 'forward_B', 'reverse_A', 'reverse_B'], np.column_stack((grid, f, r)))
    write_csv(folder / 'directional_full_states.csv', ['direction', 'eta_B_to_A', 'SU', 'SA', 'EA', 'IA', 'EB', 'IB', 'IAB', 'R'], full_states)
    fig, ax = plt.subplots(figsize=(6.5, 4.5))
    for j, (color, label) in enumerate([('#cf3c2b', 'A'), ('#1f4e79', 'B')]):
        ax.plot(grid, f[:, j], '-o', ms=3, color=color, label=label + ' forward')
        ax.plot(grid, r[:, j], '--', color=color, label=label + ' reverse')
    ax.set(xlabel='$\\eta_{B\\to A}$', ylabel='Final infected fraction')
    ax.grid(alpha=0.25)
    ax.legend(ncol=2)
    save_figure(fig, folder, 'directional_hysteresis')
    finish(folder, start, {'forward_switch_intervals': jumps, 'reverse_switch_observed_on_sampled_domain': reverse_switch, 'hysteresis_width_lower_bound': lower, 'forward_reverse_max_difference': float(abs(f - r).max()), 't_end_per_point': 6000, 'dt': 1.0, 'probe': 1e-06, 'classification_threshold': 1e-05})
if __name__ == '__main__':
    run(output_dir('experiment_08_directional_hysteresis'))
