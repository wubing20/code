import csv, math
from xml.sax.saxutils import escape
from dataclasses import replace
import numpy as np
from scipy.integrate import solve_ivp
from scipy.stats import lognorm
from common.model import GROUP_SIZES, GROUP_WEIGHTS, initial_state, rhs, invasion_growth

def trajectory(y0, p, t_end=12000.0):
    t_eval = np.unique(np.concatenate(([0.0], np.linspace(0.2, 100, 150), np.geomspace(101, t_end, 350))))
    sol = solve_ivp(lambda t, y: rhs(t, y, p), (0.0, t_end), y0, method='LSODA', t_eval=t_eval, rtol=2e-09, atol=1e-11, max_step=50.0)
    if not sol.success:
        raise RuntimeError(sol.message)
    return (sol.t, sol.y)

def reduced_stability(y, p):
    z = np.asarray(y[:7], dtype=float)

    def f(zz):
        yy = np.r_[zz, 1.0 - np.sum(zz)]
        return rhs(0.0, yy, p)[:7]
    h = 1e-06
    J = np.empty((7, 7))
    for j in range(7):
        step = np.zeros(7)
        step[j] = h
        J[:, j] = (f(z + step) - f(z - step)) / (2 * h)
    eig = np.linalg.eigvals(J)
    return (float(np.max(eig.real)), [[float(v.real), float(v.imag)] for v in eig])

def critical_interval(p, resident, upper=4.0, step=0.01, sizes=GROUP_SIZES, weights=GROUP_WEIGHTS):
    grid = np.arange(0.0, upper + 0.5 * step, step)
    growth = np.array([invasion_growth('A', resident, replace(p, eta_B_to_A=float(a)), sizes, weights) for a in grid])
    nonnegative = np.flatnonzero(growth >= 0)
    if len(nonnegative) == 0:
        return (None, None, grid, growth)
    first = int(nonnegative[0])
    low = float(grid[first - 1]) if first > 0 else 0.0
    high = float(grid[first])
    return (low, high, grid, growth)

def synthetic_lognormal_distribution(target_variance, mean_size=31.7959183673):
    if target_variance < 1:
        low = math.floor(mean_size)
        high = low + 1
        p_high = mean_size - low
        sizes = np.array([low, high], dtype=int)
        probabilities = np.array([1 - p_high, p_high], dtype=float)
    else:
        shifted_mean = mean_size - 2.0
        sigma2 = math.log(1.0 + target_variance / shifted_mean ** 2)
        sigma = math.sqrt(sigma2)
        mu = math.log(shifted_mean) - sigma2 / 2.0
        ymax = min(2500, max(100, int(lognorm.ppf(0.9999, s=sigma, scale=math.exp(mu)))))
        y = np.arange(1, ymax + 1)
        probabilities = lognorm.cdf(y + 0.5, s=sigma, scale=math.exp(mu)) - lognorm.cdf(y - 0.5, s=sigma, scale=math.exp(mu))
        probabilities[0] += lognorm.cdf(0.5, s=sigma, scale=math.exp(mu))
        probabilities[-1] += 1 - lognorm.cdf(ymax + 0.5, s=sigma, scale=math.exp(mu))
        sizes = y + 2
        mask = probabilities > 1e-08
        sizes = sizes[mask]
        probabilities = probabilities[mask]
        probabilities /= probabilities.sum()
    incidence_weights = sizes * probabilities
    incidence_weights /= incidence_weights.sum()
    mean = float(np.dot(probabilities, sizes))
    variance = float(np.dot(probabilities, (sizes - mean) ** 2))
    return (sizes, incidence_weights, mean, variance)

def write_csv(path, header, rows):
    with path.open('w', newline='', encoding='utf-8-sig') as fh:
        w = csv.writer(fh)
        w.writerow(header)
        w.writerows(rows)

def text(x, y, value, size=12, anchor='middle', weight='normal', fill='#1a1a1a', rotate=None):
    transform = f' transform="rotate({rotate} {x} {y})"' if rotate is not None else ''
    return f'<text x="{x:.2f}" y="{y:.2f}" font-family="Times New Roman,Times,serif" font-size="{size}" text-anchor="{anchor}" font-weight="{weight}" fill="{fill}"{transform}>{escape(value)}</text>'

def rich_text(x, y, segments, size=12, anchor='middle', fill='#1a1a1a', rotate=None):
    transform = f' transform="rotate({rotate} {x} {y})"' if rotate is not None else ''
    parts = []
    for value, mode in segments:
        attrs = []
        if mode in ('math', 'sub', 'sup'):
            attrs.append('font-style="italic"')
        if mode == 'sub':
            attrs.extend(['baseline-shift="sub"', 'font-size="70%"'])
        elif mode == 'sup':
            attrs.extend(['baseline-shift="super"', 'font-size="70%"'])
        parts.append(f"<tspan {' '.join(attrs)}>{escape(value)}</tspan>")
    return f'''<text x="{x:.2f}" y="{y:.2f}" font-family="Times New Roman,Times,serif" font-size="{size}" text-anchor="{anchor}" fill="{fill}"{transform}>{''.join(parts)}</text>'''

def star_points(cx, cy, outer=7, inner=3.2):
    pts = []
    for i in range(10):
        angle = -math.pi / 2 + i * math.pi / 5
        r = outer if i % 2 == 0 else inner
        pts.append(f'{cx + r * math.cos(angle):.2f},{cy + r * math.sin(angle):.2f}')
    return ' '.join(pts)

def axes(parts, x, y, w, h, xlim, ylim, xticks, yticks, xlabel_segments, ylabel_segments):
    for tick in xticks:
        px = x + (tick - xlim[0]) / (xlim[1] - xlim[0]) * w
        parts.append(f'<line x1="{px:.2f}" y1="{y:.2f}" x2="{px:.2f}" y2="{y + h:.2f}" stroke="#dddddd" stroke-width="0.7"/>')
        parts.append(text(px, y + h + 18, f'{tick:g}', 10))
    for tick in yticks:
        py = y + h - (tick - ylim[0]) / (ylim[1] - ylim[0]) * h
        parts.append(f'<line x1="{x:.2f}" y1="{py:.2f}" x2="{x + w:.2f}" y2="{py:.2f}" stroke="#dddddd" stroke-width="0.7"/>')
        parts.append(text(x - 8, py + 3, f'{tick:g}', 10, 'end'))
    parts.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="none" stroke="#1a1a1a" stroke-width="1.1"/>')
    parts.append(rich_text(x + w / 2, y + h + 40, xlabel_segments, 12))
    parts.append(rich_text(x - 43, y + h / 2, ylabel_segments, 12, rotate=-90))

    def map_point(xx, yy):
        return (x + (xx - xlim[0]) / (xlim[1] - xlim[0]) * w, y + h - (yy - ylim[0]) / (ylim[1] - ylim[0]) * h)
    return map_point
