from common.model import Parameters
BASE = Parameters(beta_A_L=0.00534453, beta_B_L=0.0075, beta_A_H=0.13233903, beta_B_H=0.04, alpha_A=0.25, alpha_B=0.25, mu_A=0.1, mu_B=0.1, mu_AB=0.12, omega=0.08, theta_A0=0.3, theta_B0=0.28, eta_B_to_A=0.0, eta_A_to_B=0.0, omega_aw=0.0, delta_aw=0.08, theta_aw=0.1, sigma_A=0.2, sigma_B=0.2)
INITIALS = {'Symmetric IC': (0.4, 0.4), 'A-biased IC': (0.6, 0.1), 'B-biased IC': (0.1, 0.6)}
COLORS = {'Symmetric IC': '#7d3c98', 'A-biased IC': '#cf3c2b', 'B-biased IC': '#1f4e79', 'A': '#cf3c2b', 'B': '#1f4e79', 'green': '#2ca25f', 'purple': '#7d3c98'}
