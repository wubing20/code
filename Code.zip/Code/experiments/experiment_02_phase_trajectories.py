from pathlib import Path
import sys, time
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from dataclasses import replace
import numpy as np
from common.model import initial_state, rhs
from common.config import BASE, INITIALS, COLORS
from common.numerics import trajectory, reduced_stability
from common.output import output_dir, write_csv, save_figure, finish, plt

def run(folder):
    start = time.perf_counter()
    rows = []
    full_rows = []
    equilibria = []
    fig, axes = plt.subplots(1, 3, figsize=(12, 4.55))
    for ax, eta in zip(axes, [0.0, 0.739, 2.0]):
        p = replace(BASE, eta_B_to_A=eta)
        for name, (a0, b0) in INITIALS.items():
            t, y = trajectory(initial_state(a0, b0), p)
            a = y[3] + y[6]
            b = y[5] + y[6]
            rows.extend(zip([eta] * len(t), [name] * len(t), t, a, b))
            full_rows.extend(((eta, name, float(tt), *state) for tt, state in zip(t, y.T)))
            final = np.maximum(y[:, -1], 0)
            final /= final.sum()
            leading, _ = reduced_stability(final, p)
            equilibria.append({'eta_B_to_A': eta, 'initial_condition': name, 'state': final.tolist(), 'residual_inf': float(abs(rhs(0, final, p)).max()), 'last_10_percent_time_window_drift': float(np.ptp(y[:, t >= 0.9 * t[-1]], axis=1).max()), 'central_difference_eigenvalue': leading})
            ax.plot(a, b, color=COLORS[name], label=name)
            ax.plot(a[-1], b[-1], '*', color='#f4b400', markeredgecolor='black', ms=10)
        ax.set(xlim=(0, 0.65), ylim=(0, 0.65), xlabel='$\\bar\\rho_A$', ylabel='$\\bar\\rho_B$', title=f'$\\eta_{{B\\to A}}={eta:g}$')
        ax.grid(alpha=0.25)
    axes[1].legend(fontsize=7)
    write_csv(folder / 'trajectories.csv', ['eta_B_to_A', 'initial_condition', 'time', 'rho_A', 'rho_B'], rows)
    write_csv(folder / 'full_state_trajectories.csv', ['eta_B_to_A', 'initial_condition', 'time', 'SU', 'SA', 'EA', 'IA', 'EB', 'IB', 'IAB', 'R'], full_rows)
    save_figure(fig, folder, 'phase_trajectories')
    finish(folder, start, {'equilibria': equilibria, 'trajectory_count': 9, 't_end': 12000})
if __name__ == '__main__':
    run(output_dir('experiment_02_phase_trajectories'))
