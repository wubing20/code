import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def render_validation(RESULTS, OUT):
    table = np.loadtxt(RESULTS / 'experiment_07_jacobian_stability/jacobian_scan.csv', delimiter=',', skiprows=1, encoding='utf-8-sig')
    alpha_eig, leading = (table[:, 0], table[:, 1])
    rec = json.loads((RESULTS / 'experiment_07_jacobian_stability/summary.json').read_text())
    critical_low, critical_high = rec['critical_intervals'][0]
    table = np.loadtxt(RESULTS / 'experiment_08_directional_hysteresis/directional_scan.csv', delimiter=',', skiprows=1, encoding='utf-8-sig')
    scan_alpha = table[:, 0]
    forward = table[:, 1:3]
    reverse = table[:, 3:5]
    data = np.load(RESULTS / 'experiment_09_dense_basins/basin_grid.npz')
    xx, yy, labels = (data['x'], data['y'], data['labels'])
    rec = json.loads((RESULTS / 'experiment_10_boundary_uncertainty/summary.json').read_text())
    fractions = rec['basin_area_fractions']
    gamma = rec['uncertainty_exponent']
    plt.rcParams.update({'font.family': 'Times New Roman', 'font.size': 10})
    fig, axs = plt.subplots(2, 2, figsize=(9.2, 7.0), dpi=180)
    ax = axs[0, 0]
    ax.plot(alpha_eig, leading, color='#7d3c98', lw=2)
    ax.axhline(0, color='black', lw=0.8)
    ax.axvspan(critical_low, critical_high, color='#f4b400', alpha=0.25)
    ax.set(xlabel='Cross-modulation $\\eta_{B\\to A}$', ylabel='Leading real eigenvalue')
    ax.set_title('(a) Jacobian stability of the B-resident state')
    ax.text((critical_low + critical_high) / 2, ax.get_ylim()[1] * 0.8, f'[{critical_low:.2f}, {critical_high:.2f}]', ha='center')
    ax.grid(alpha=0.25)
    ax = axs[0, 1]
    f = np.asarray(forward)
    r = np.asarray(reverse)
    ax.plot(scan_alpha, f[:, 0], '-o', ms=3, color='#cf3c2b', label='A, forward')
    ax.plot(scan_alpha, r[:, 0], '--', color='#cf3c2b', label='A, reverse')
    ax.plot(scan_alpha, f[:, 1], '-s', ms=3, color='#1f4e79', label='B, forward')
    ax.plot(scan_alpha, r[:, 1], '--', color='#1f4e79', label='B, reverse')
    ax.set(xlabel='Cross-modulation $\\eta_{B\\to A}$', ylabel='Asymptotic infected fraction')
    ax.set_title('(b) Directional scans and open hysteresis loop')
    ax.legend(frameon=False, ncol=2, fontsize=8)
    ax.grid(alpha=0.25)
    ax = axs[1, 0]
    from matplotlib.colors import ListedColormap
    cmap = ListedColormap(['#1f4e79', '#cf3c2b', '#2ca25f'])
    ax.pcolormesh(xx, yy, np.ma.masked_invalid(labels), shading='auto', cmap=cmap, vmin=0, vmax=2)
    ax.set(xlabel='Initial infected fraction $\\rho_A(0)$', ylabel='Initial infected fraction $\\rho_B(0)$')
    ax.set_title('(c) 201×201 initial-condition slice at $\\eta_{B\\to A}=0.739$')
    ax.text(0.04, 0.94, f"Coexistence: {100 * fractions['coexistence']:.1f}%\nA-only: {100 * fractions['A_only']:.1f}%", transform=ax.transAxes, va='top', color='black', weight='bold', bbox=dict(facecolor='white', alpha=0.8, edgecolor='none'))
    ax = axs[1, 1]
    vals = [100 * fractions['coexistence'], 100 * fractions['A_only'], 100 * fractions['B_only']]
    bars = ax.bar(['Coexistence', 'A-only', 'B-only'], vals, color=['#2ca25f', '#cf3c2b', '#1f4e79'])
    ax.set_ylim(0, 105)
    ax.set_ylabel('Area fraction (%)')
    ax.set_title('(d) Basin-area ratio and boundary test')
    for bar, val in zip(bars, vals):
        ax.text(bar.get_x() + bar.get_width() / 2, val + 2, f'{val:.1f}%', ha='center')
    ax.text(0.58, 0.58, f'Uncertainty exponent $\\gamma={gamma:.3f}$\nBoundary dimension $D_b={2 - gamma:.3f}$', transform=ax.transAxes, ha='center', fontsize=9)
    ax.grid(axis='y', alpha=0.25)
    fig.tight_layout()
    fig.savefig(OUT / 'Figure6_stability_basin_validation.png', bbox_inches='tight', facecolor='white')
    fig.savefig(OUT / 'Figure6_stability_basin_validation.svg', bbox_inches='tight', facecolor='white')
    plt.close(fig)
