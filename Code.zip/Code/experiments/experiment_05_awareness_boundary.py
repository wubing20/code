from pathlib import Path
import sys, time
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from dataclasses import replace
import numpy as np
from common.config import BASE
from common.model import resident_equilibrium
from common.numerics import critical_interval
from common.output import output_dir, write_csv, save_figure, finish, plt

def run(folder):
    start = time.perf_counter()
    rows = []
    for delta in np.arange(0, 0.2001, 0.025):
        p = replace(BASE, omega_aw=0.5, delta_aw=0.08, theta_aw=0.1, sigma_A=0.2 + float(delta), sigma_B=0.2)
        resident = resident_equilibrium('B', p, aware_seed=0.1)
        low, high, _, _ = critical_interval(p, resident, upper=4, step=0.01)
        midpoint = None if high is None else (low + high) / 2
        rows.append((delta, low, high, midpoint, float(resident[1]), float(resident[5])))
    write_csv(folder / 'awareness_boundary.csv', ['delta_sigma', 'critical_low', 'critical_high', 'critical_midpoint', 'resident_aware_fraction', 'resident_I_B'], rows)
    fig, ax = plt.subplots(figsize=(6.5, 4.5))
    ax.plot([r[0] for r in rows], [r[3] for r in rows], '-o', color='#2ca25f')
    low, high, _, _ = critical_interval(BASE, resident_equilibrium('B', BASE), upper=3, step=0.01)
    if high is not None:
        ax.axhline((low + high) / 2, ls='--', color='gray', label='No-awareness approximation')
    ax.set(xlabel='$\\Delta\\sigma$', ylabel='Earlier critical $\\eta_{B\\to A}$')
    ax.grid(alpha=0.25)
    ax.legend(fontsize=8)
    save_figure(fig, folder, 'awareness_boundary')
    finish(folder, start, {'points': len(rows), 'aware_seed': 0.1})
if __name__ == '__main__':
    run(output_dir('experiment_05_awareness_boundary'))
