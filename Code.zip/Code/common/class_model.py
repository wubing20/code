from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from scipy.special import expit, logit
from scipy.stats import binom
STATE_NAMES = ('SU', 'SA', 'EA', 'IA', 'EB', 'IB', 'IAB', 'R')

@dataclass
class ClassHMF:
    network: dict
    parameters: object
    threshold_driver: str
    awareness_closure: str | None = None

    def __post_init__(self):
        if self.threshold_driver not in ('focal', 'rival'):
            raise ValueError('Select threshold_driver: focal or rival.')
        if self.parameters.omega_aw and self.awareness_closure != 'class_fraction':
            raise ValueError('Set awareness_closure to class_fraction when omega_aw is nonzero.')
        self.classes = np.asarray(self.network['classes'])
        self.probability = np.asarray(self.network['probability'])
        self.k = self.classes[:, 0]
        self.q = self.classes[:, 1]
        self.mean_k = float(self.k @ self.probability)
        self.sizes = np.asarray(self.network['sizes'])
        counts = np.asarray(self.network['size_counts'])
        self.size_probability = counts / counts.sum()
        self.conditional = np.asarray(self.network['conditional_size_given_class'])

    def initial(self, rho_a=0.01, rho_b=0.01, aware=0.0):
        if min(rho_a, rho_b, aware) < 0 or rho_a + rho_b + aware > 1:
            raise ValueError('Invalid initial fractions')
        result = np.zeros((len(self.classes), 8))
        result[:, 0] = 1 - rho_a - rho_b - aware
        result[:, 1] = aware
        result[:, 3] = rho_a
        result[:, 5] = rho_b
        return result

    def densities(self, y):
        state = np.asarray(y, float).reshape((-1, 8))
        a = state[:, 3] + state[:, 6]
        b = state[:, 5] + state[:, 6]
        rho_a = float(self.probability @ a)
        rho_b = float(self.probability @ b)
        if self.mean_k:
            theta_a = float(self.k * self.probability @ a / self.mean_k)
            theta_b = float(self.k * self.probability @ b / self.mean_k)
        else:
            theta_a = theta_b = 0.0
        return (rho_a, rho_b, theta_a, theta_b)

    def group_tail(self, prevalence, base, coupling, modulating_density):
        threshold = float(expit(logit(base) - coupling * modulating_density))
        n = self.sizes - 1
        required = np.ceil(n * threshold).astype(int)
        tail = binom.sf(required - 1, n, np.clip(prevalence, 0, 1))
        return float(self.size_probability @ tail)

    def forces(self, y):
        p = self.parameters
        a, b, edge_a, edge_b = self.densities(y)
        mod_a, mod_b = (a, b) if self.threshold_driver == 'focal' else (b, a)
        force_a = p.beta_A_L * self.k * edge_a + p.beta_A_H * self.q * self.group_tail(a, p.theta_A0, p.eta_B_to_A, mod_a)
        force_b = p.beta_B_L * self.k * edge_b + p.beta_B_H * self.q * self.group_tail(b, p.theta_B0, p.eta_A_to_B, mod_b)
        return (force_a, force_b)

    def rhs(self, t, y):
        shape = np.shape(y)
        state = np.asarray(y, float).reshape((-1, 8))
        SU, SA, EA, IA, EB, IB, IAB, R = state.T
        p = self.parameters
        fA, fB = self.forces(state)
        if p.omega_aw:
            n = self.sizes - 1
            required = np.ceil(n * p.theta_aw).astype(int)
            tail = binom.sf(required[None, :] - 1, n[None, :], np.clip(SA, 0, 1)[:, None])
            awareness = p.omega_aw * np.sum(self.conditional * tail, axis=1)
        else:
            awareness = np.zeros(len(self.classes))
        a = fA * (SU + (1 - p.sigma_A) * SA)
        b = fB * (SU + (1 - p.sigma_B) * SA)
        secondary_a = fA * IB
        secondary_b = fB * IA
        dy = np.column_stack((p.omega * R + p.delta_aw * SA - awareness * SU - (fA + fB) * SU, awareness * SU - p.delta_aw * SA - ((1 - p.sigma_A) * fA + (1 - p.sigma_B) * fB) * SA, a - p.alpha_A * EA, p.alpha_A * EA - p.mu_A * IA - secondary_b, b - p.alpha_B * EB, p.alpha_B * EB - p.mu_B * IB - secondary_a, secondary_a + secondary_b - p.mu_AB * IAB, p.mu_A * IA + p.mu_B * IB + p.mu_AB * IAB - p.omega * R))
        return dy.reshape(shape)

    def rare_invader_force_matrix(self, invader, resident_state):
        if invader not in ('A', 'B'):
            raise ValueError(invader)
        p = self.parameters
        a, b, _, _ = self.densities(resident_state)
        if invader == 'A':
            beta_l, beta_h, base, eta, rival = (p.beta_A_L, p.beta_A_H, p.theta_A0, p.eta_B_to_A, b)
        else:
            beta_l, beta_h, base, eta, rival = (p.beta_B_L, p.beta_B_H, p.theta_B0, p.eta_A_to_B, a)
        mod = 0.0 if self.threshold_driver == 'focal' else rival
        value = float(expit(logit(base) - eta * mod))
        n = self.sizes - 1
        required = np.ceil(n * value).astype(int)
        slope = float(self.size_probability @ (n * (required == 1)))
        edge_weight = self.k * self.probability / self.mean_k if self.mean_k else np.zeros_like(self.probability)
        return beta_l * self.k[:, None] * edge_weight[None, :] + beta_h * self.q[:, None] * slope * self.probability[None, :]
