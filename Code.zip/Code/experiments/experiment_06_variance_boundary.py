from pathlib import Path
import sys, time
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
from common.config import BASE
from common.model import resident_equilibrium, GROUP_SIZES, GROUP_WEIGHTS
from common.numerics import critical_interval, synthetic_lognormal_distribution
from common.output import output_dir, write_csv, save_figure, finish, plt

def run(folder):
    start = time.perf_counter()
    rows = []
    for target in [0.1, 50, 200, 500, 1000, 5000, 10000, 16000]:
        sizes, weights, mean, var = synthetic_lognormal_distribution(target)
        resident = resident_equilibrium('B', BASE, sizes=sizes, weights=weights)
        low, high, _, _ = critical_interval(BASE, resident, upper=6, step=0.02, sizes=sizes, weights=weights)
        mid = None if high is None else (low + high) / 2
        rows.append((str(target), var, mean, len(sizes), low, high, mid, float(resident[5])))
        print('variance', target, 'finished', flush=True)
    prob = GROUP_WEIGHTS / GROUP_SIZES
    prob /= prob.sum()
    mean = float(prob @ GROUP_SIZES)
    var = float(prob @ (GROUP_SIZES - mean) ** 2)
    resident = resident_equilibrium('B', BASE)
    low, high, _, _ = critical_interval(BASE, resident, upper=3, step=0.01)
    rows.append(('empirical', var, mean, len(GROUP_SIZES), low, high, (low + high) / 2, float(resident[5])))
    write_csv(folder / 'variance_boundary.csv', ['target_variance', 'achieved_variance', 'mean_size', 'support_size_count', 'critical_low', 'critical_high', 'critical_midpoint', 'resident_I_B'], rows)
    fig, ax = plt.subplots(figsize=(6.5, 4.5))
    for idx, r in enumerate(rows[:-1]):
        ax.plot(r[1], 6.05 if r[6] is None else r[6], '^' if r[6] is None else 'o', color='#2ca25f')
    ax.plot([r[1] for r in rows[:-1]], [6.05 if r[6] is None else r[6] for r in rows[:-1]], color='#2ca25f')
    ax.plot(rows[-1][1], rows[-1][6], '*', ms=12, color='#f4b400', markeredgecolor='black', label='empirical')
    ax.text(0.02, 0.95, 'Triangle: boundary > 6 (displayed at 6.05)', transform=ax.transAxes, va='top', fontsize=8)
    ax.set(xlabel='Hyperedge-size variance', ylabel='Earlier critical $\\eta_{B\\to A}$')
    ax.grid(alpha=0.25)
    ax.legend()
    save_figure(fig, folder, 'variance_boundary')
    finish(folder, start, {'points': len(rows)})
if __name__ == '__main__':
    run(output_dir('experiment_06_variance_boundary'))
