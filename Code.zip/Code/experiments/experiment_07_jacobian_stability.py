from pathlib import Path
import sys, time
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from dataclasses import replace
import numpy as np
from common.config import BASE
from common.model import resident_equilibrium, integrate, initial_state, rhs
from common.validation_numerics import reduced_jacobian
from common.output import output_dir, write_csv, save_figure, finish, plt

def run(folder):
    start = time.perf_counter()
    resident = resident_equilibrium('B', BASE)
    grid = np.arange(0.2, 0.501, 0.01)
    rows = []
    for eta in grid:
        _, eig = reduced_jacobian(resident, replace(BASE, eta_B_to_A=float(eta)), one_sided=True)
        rows.append((eta, float(eig.real.max())))
        print('Jacobian', float(eta), rows[-1][1], flush=True)
    y = np.array(rows)[:, 1]
    crossings = [(float(grid[i - 1]), float(grid[i])) for i in range(1, len(grid)) if y[i - 1] < 0 < y[i]]
    eq = integrate(initial_state(0.4, 0.4), replace(BASE, eta_B_to_A=0.739), t_end=15000)
    _, eig = reduced_jacobian(eq, replace(BASE, eta_B_to_A=0.739), one_sided=False)
    high_a = integrate(initial_state(0.6, 0.1), replace(BASE, eta_B_to_A=0.739), t_end=15000)
    _, high_a_eig = reduced_jacobian(high_a, replace(BASE, eta_B_to_A=0.739), one_sided=True)
    write_csv(folder / 'jacobian_scan.csv', ['eta_B_to_A', 'leading_real_eigenvalue'], rows)
    fig, ax = plt.subplots(figsize=(6.5, 4.5))
    ax.plot(grid, y, color='#7d3c98')
    ax.axhline(0, color='black', lw=0.8)
    for lo, hi in crossings:
        ax.axvspan(lo, hi, color='#f4b400', alpha=0.25)
    ax.set(xlabel='$\\eta_{B\\to A}$', ylabel='Leading real eigenvalue')
    ax.grid(alpha=0.25)
    save_figure(fig, folder, 'jacobian_stability')
    finish(folder, start, {'critical_intervals': crossings, 'coexistence_equilibrium': eq.tolist(), 'coexistence_spectral_abscissa': float(eig.real.max()), 'equilibrium_residual': float(abs(rhs(0, eq, replace(BASE, eta_B_to_A=0.739))).max()), 'high_A_equilibrium': high_a.tolist(), 'high_A_one_sided_spectral_abscissa': float(high_a_eig.real.max()), 'high_A_residual_inf': float(abs(rhs(0, high_a, replace(BASE, eta_B_to_A=0.739))).max())})
if __name__ == '__main__':
    run(output_dir('experiment_07_jacobian_stability'))
