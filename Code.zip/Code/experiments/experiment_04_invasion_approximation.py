from pathlib import Path
import sys, time
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common.config import BASE
from common.model import resident_equilibrium
from common.numerics import critical_interval
from common.output import output_dir, write_csv, save_figure, finish, plt

def run(folder):
    start = time.perf_counter()
    resident = resident_equilibrium('B', BASE)
    low, high, x, y = critical_interval(BASE, resident, upper=3, step=0.01)
    write_csv(folder / 'invasion_scan.csv', ['eta_B_to_A', 'invasion_growth'], zip(x, y))
    fig, ax = plt.subplots(figsize=(6.5, 4.5))
    ax.plot(x, y, color='#7d3c98')
    ax.axhline(0, color='black', lw=0.8)
    if low is not None:
        ax.axvspan(low, high, color='#f4b400', alpha=0.25)
    ax.set(xlabel='$\\eta_{B\\to A}$', ylabel='Earlier invasion growth approximation')
    ax.grid(alpha=0.25)
    save_figure(fig, folder, 'invasion_approximation')
    finish(folder, start, {'critical_interval': [low, high], 'resident': resident.tolist()})
if __name__ == '__main__':
    run(output_dir('experiment_04_invasion_approximation'))
